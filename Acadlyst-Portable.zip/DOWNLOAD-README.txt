ACADLYST CAMPUS ERP

1. Extract the ZIP to a folder.
2. Double-click portable-start.bat.
3. The app opens in your default browser at http://127.0.0.1:4173/.
4. In Microsoft Edge or Chrome, use the browser menu to install Acadlyst as an app.

Node.js 18 or newer is required to run the portable package. The app shell and
loaded files are cached for offline use after the first visit. User data is
stored in the browser's local storage on this computer.