import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, resolve, sep } from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const appDirectory = resolve(fileURLToPath(new URL('.', import.meta.url)));
const distDirectory = resolve(appDirectory, 'dist');
const port = 4173;
const mimeTypes = {
    '.css': 'text/css; charset=utf-8',
    '.html': 'text/html; charset=utf-8',
    '.ico': 'image/x-icon',
    '.js': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.webmanifest': 'application/manifest+json; charset=utf-8'
};

const server = createServer((request, response) => {
    const url = new URL(request.url || '/', `http://127.0.0.1:${port}`);

    if (url.pathname === '/api/db') {
        response.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        response.end(request.method === 'GET' ? 'null' : JSON.stringify({ status: 200 }));
        return;
    }

    let requestedPath;
    try {
        requestedPath = decodeURIComponent(url.pathname);
    } catch {
        response.writeHead(400).end('Bad request');
        return;
    }

    const candidatePath = resolve(distDirectory, `.${requestedPath}`);
    if (candidatePath !== distDirectory && !candidatePath.startsWith(`${distDirectory}${sep}`)) {
        response.writeHead(403).end('Forbidden');
        return;
    }

    const filePath = existsSync(candidatePath) && statSync(candidatePath).isDirectory()
        ? resolve(candidatePath, 'index.html')
        : candidatePath;
    const selectedFile = existsSync(filePath) ? filePath : resolve(distDirectory, 'index.html');
    const contentType = mimeTypes[extname(selectedFile).toLowerCase()] || 'application/octet-stream';
    response.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': selectedFile.includes(`${sep}assets${sep}`) ? 'public, max-age=31536000, immutable' : 'no-cache',
        'X-Content-Type-Options': 'nosniff'
    });
    createReadStream(selectedFile).pipe(response);
});

server.listen(port, '127.0.0.1', () => {
    const url = `http://127.0.0.1:${port}/`;
    console.log(`Acadlyst is running at ${url}`);
    if (process.platform === 'win32') {
        spawn('cmd.exe', ['/c', 'start', '', url], { detached: true, stdio: 'ignore' }).unref();
    }
});