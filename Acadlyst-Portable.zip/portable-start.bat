@echo off
title Acadlyst Campus ERP
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer is required to run this portable app.
  echo Download it from https://nodejs.org/
  pause
  exit /b 1
)
node portable-server.mjs
pause